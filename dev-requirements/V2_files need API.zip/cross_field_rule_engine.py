#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
CROSS-FIELD BUSINESS RULE ENGINE  --  generic (role-based) KB, IRB + IFRS 9
================================================================================
MVP Test Plan, Test 2 (hard mode). Implements CrossFieldRule_Test_Spec_v2.

KEY IDEA (this version)
    The Knowledge Base is GENERIC. Rules are written in SEMANTIC ROLES, never
    in physical column names:

        rule "exposure >= drawn balance"  ->  roles: exposure_at_default,
                                                     drawn_balance

    At run time the engine RESOLVES each role to a real column in whatever
    dataset you loaded, using TWO layers:

        1. AUTO-MATCH  -- scores every column against each role using the data
                          dictionary description + a synonym vocabulary + name
                          similarity. Best confident match wins.
        2. OVERRIDE    -- an optional mapping file (role -> column) that BEATS
                          any auto guess. Supply only the roles you want to pin.

    A rule whose roles all resolve -> RUNS. A rule with any unresolved role ->
    NOT-APPLICABLE ("role X unmapped"), never silently skipped.

SCOPE OF THE BUILT-IN KB:  IRB (PD/LGD: EAD, DoD, workout, recovery) and
    IFRS 9 (staging, SICR-via-DPD, forbearance, ECL component sanity).

NO AI.  Pure deterministic Python (pandas + stdlib).

--------------------------------------------------------------------------------
HOW TO RUN  (folder-based; drop any dataset into a folder and point here)
--------------------------------------------------------------------------------
    # Put your data file + (optional) mapping.json + dictionary.json in one folder.
    python cross_field_rule_engine.py --folder /path/to/my_run_folder

    The engine auto-discovers, inside the folder:
        *.xlsx / *.csv          -> the dataset          (required)
        dictionary.json         -> data dictionary       (optional, aids matching)
        mapping.json            -> manual role overrides  (optional)
    and writes report.txt + resolution_map.json back into the same folder.

    Explicit paths still work:
    python cross_field_rule_engine.py --data d.xlsx [--dictionary dict.json]
           [--mapping map.json] [--report out.txt]

    Other:
    --dump-roles roles.json   dump the role vocabulary (edit + reuse)
    --quiet                   suppress the intermediary (step-by-step) output
================================================================================
"""

from __future__ import annotations

import argparse
import difflib
import glob
import json
import re
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Optional

import pandas as pd


# ============================================================================
#  VERBOSE / INTERMEDIARY OUTPUT
# ============================================================================
_VERBOSE = True

# IFRS 9 staging domain. Default = IAS/IFRS9 stages {1,2,3}. A dataset whose
# staging column uses a different set (e.g. a 0-based DPD bucket) can override
# this via the mapping file key "_stage_domain": [0,1,2,3]. No code edit needed.
_STAGE_DOMAIN = [1, 2, 3]


def step(title: str) -> None:
    if _VERBOSE:
        print("\n" + "-" * 78)
        print(f">>> {title}")
        print("-" * 78)


def note(msg: str) -> None:
    if _VERBOSE:
        print("    " + msg)


# ============================================================================
#  SECTION 0.  SMALL UTILITIES
# ============================================================================

def _is_missing(v: Any) -> bool:
    if v is None:
        return True
    try:
        if pd.isna(v):
            return True
    except (TypeError, ValueError):
        pass
    if isinstance(v, str) and v.strip().lower() in ("", "nan", "none", "null", "na", "n/a"):
        return True
    return False


def _to_number(v: Any) -> Optional[float]:
    if _is_missing(v):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _to_date(v: Any) -> Optional[datetime]:
    if _is_missing(v):
        return None
    if isinstance(v, datetime):
        return v
    if isinstance(v, (int, float)):
        return None
    s = str(v).strip()
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y", "%m/%d/%Y",
                "%Y/%m/%d", "%Y-%m", "%d-%m-%Y"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


# ============================================================================
#  SECTION 1.  ROLE VOCABULARY  (edit here to add semantic roles)
# ============================================================================
# A role is a semantic concept the KB refers to. Each role carries:
#   entity   : which semantic table it belongs to (used to pick the dataset table)
#   synonyms : words/phrases identifying the role in a column name or its
#              dictionary description (lower-case, matched as substrings)
#   dtype    : expected kind ('number','date','flag','category') -- breaks ties
#              and rejects implausible matches

ROLE_VOCAB: dict[str, dict] = {
    # ---------------- IRB / LGD workout & recovery ----------------
    "exposure_at_default":   {"entity": "workout", "dtype": "number",
                              "synonyms": ["exposure at default", "ead", "exposure"]},
    "drawn_balance":         {"entity": "workout", "dtype": "number",
                              "synonyms": ["drawn balance", "balance at default",
                                           "balance_at_default", "outstanding balance"]},
    "workout_state":         {"entity": "workout", "dtype": "category",
                              "synonyms": ["workout status", "workout state",
                                           "recovery status", "resolution status"]},
    "cure_indicator":        {"entity": "workout", "dtype": "flag",
                              "synonyms": ["cure flag", "cured", "cure indicator"]},
    "possession_date":       {"entity": "workout", "dtype": "date",
                              "synonyms": ["possession date", "repossession date"]},
    "sale_date":             {"entity": "workout", "dtype": "date",
                              "synonyms": ["sale date", "disposal date"]},
    "sale_proceeds":         {"entity": "workout", "dtype": "number",
                              "synonyms": ["sale proceeds", "recovery proceeds",
                                           "disposal proceeds"]},
    "legal_costs":           {"entity": "workout", "dtype": "number",
                              "synonyms": ["legal costs", "legal cost"]},
    "other_costs":           {"entity": "workout", "dtype": "number",
                              "synonyms": ["other costs", "workout costs", "admin costs"]},
    "insurance_recovery":    {"entity": "workout", "dtype": "number",
                              "synonyms": ["insurance recovery", "insurance recoveries"]},
    "time_to_resolution":    {"entity": "workout", "dtype": "number",
                              "synonyms": ["time to resolution", "resolution months",
                                           "workout period"]},
    "realised_loss":         {"entity": "workout", "dtype": "number",
                              "synonyms": ["realised loss", "realized loss", "loss amount"]},
    "realised_lgd":          {"entity": "workout", "dtype": "number",
                              "synonyms": ["realised lgd", "realized lgd", "lgd",
                                           "loss given default"]},

    # ---------------- IRB / origination & collateral ----------------
    "original_balance":      {"entity": "facility", "dtype": "number",
                              "synonyms": ["original balance", "origination balance",
                                           "loan amount", "original_balance"]},
    "original_property_value": {"entity": "facility", "dtype": "number",
                              "synonyms": ["original property value", "property value",
                                           "collateral value", "original_property_value"]},
    "original_ltv":          {"entity": "facility", "dtype": "number",
                              "synonyms": ["original ltv", "ltv at origination",
                                           "loan to value", "original_ltv"]},
    "term_months":           {"entity": "facility", "dtype": "number",
                              "synonyms": ["term months", "loan term", "tenor",
                                           "term_months"]},
    "interest_rate":         {"entity": "facility", "dtype": "number",
                              "synonyms": ["original interest rate", "interest rate",
                                           "coupon"]},
    "ftb_indicator":         {"entity": "facility", "dtype": "flag",
                              "synonyms": ["ftb flag", "first time buyer", "ftb"]},

    # ---------------- IRB / PD spine + IFRS 9 staging ----------------
    "current_balance":       {"entity": "snapshot", "dtype": "number",
                              "synonyms": ["current balance", "current_balance"]},
    "indexed_property_value": {"entity": "snapshot", "dtype": "number",
                              "synonyms": ["indexed property value", "indexed collateral",
                                           "indexed_property_value"]},
    "indexed_ltv":           {"entity": "snapshot", "dtype": "number",
                              "synonyms": ["indexed ltv", "current ltv", "indexed_ltv"]},
    "days_past_due":         {"entity": "snapshot", "dtype": "number",
                              "synonyms": ["days past due", "dpd", "arrears days"]},
    "ifrs9_stage":           {"entity": "snapshot", "dtype": "number",
                              "synonyms": ["ifrs9 stage", "ifrs 9 stage", "staging",
                                           "delinquency stage", "delinquency_stage",
                                           "impairment stage", "ecl stage"]},
    "forbearance_indicator": {"entity": "snapshot", "dtype": "flag",
                              "synonyms": ["forbearance flag", "forborne",
                                           "forbearance", "forbearance_flag"]},
    "restructure_indicator": {"entity": "snapshot", "dtype": "flag",
                              "synonyms": ["restructure flag", "restructured",
                                           "restructure_flag"]},
    "months_on_book":        {"entity": "snapshot", "dtype": "number",
                              "synonyms": ["months on book", "seasoning",
                                           "months_on_book"]},
    "dod_regime":            {"entity": "snapshot", "dtype": "category",
                              "synonyms": ["dod regime", "default definition version",
                                           "dod_regime_version"]},

    # ---------------- IRB / default event ----------------
    "default_date":          {"entity": "default", "dtype": "date",
                              "synonyms": ["default date", "date of default",
                                           "default_date"]},
    "dod_basis":             {"entity": "default", "dtype": "category",
                              "synonyms": ["dod basis", "default basis", "dod_basis"]},
    "materiality_indicator": {"entity": "default", "dtype": "flag",
                              "synonyms": ["materiality flag", "materiality",
                                           "materiality_flag"]},

    # ---------------- borrower ----------------
    "age_at_origination":    {"entity": "borrower", "dtype": "number",
                              "synonyms": ["age at origination", "borrower age",
                                           "age_at_origination"]},
    "income_at_origination": {"entity": "borrower", "dtype": "number",
                              "synonyms": ["income at origination", "borrower income",
                                           "income_at_origination"]},

    # ---------------- valuation ----------------
    "valuation_amount":      {"entity": "valuation", "dtype": "number",
                              "synonyms": ["valuation amount", "appraisal value",
                                           "valuation_amount"]},
    "indexed_flag":          {"entity": "valuation", "dtype": "flag",
                              "synonyms": ["indexed flag", "is indexed", "indexed_flag"]},

    # ---------------- grain / keys ----------------
    "facility_id":           {"entity": "*", "dtype": "number",
                              "synonyms": ["loan id", "facility id", "account id",
                                           "loan_id", "contract id"]},
    "region":                {"entity": "*", "dtype": "category",
                              "synonyms": ["region", "geography"]},
}


# ============================================================================
#  SECTION 2.  RULE OBJECT  (roles, not columns)
# ============================================================================
RULE_TYPES = ("inequality", "date_ordering", "identity", "conditional", "domain")
SEVERITIES = ("CRITICAL", "MATERIAL", "MINOR")


@dataclass
class Rule:
    id: str
    entity: str
    rule_type: str
    description: str
    roles: list[str]
    framework: str
    build: Callable[[dict], tuple]           # (role->col map) -> (condition_fn, expression_fn)
    tolerance: float = 0.0
    severity: str = "MATERIAL"
    exceptions_spec: list[tuple] = field(default_factory=list)   # (role, value) equals-exceptions
    exception_notes: list[str] = field(default_factory=list)
    presence_sensitive_roles: list[str] = field(default_factory=list)
    source: str = "KB"
    reg_reference: str = ""          # regulatory citation (CRR / EBA GL / IFRS 9 para)


# ---- expression/condition primitives (operate on resolved column names) ----

def _always(_row):
    return True


def ineq(colA, op, colB_or_lit, tol=0.0):
    lit = colB_or_lit[1:] if isinstance(colB_or_lit, str) and colB_or_lit.startswith("#") else None
    lit = float(lit) if lit is not None else None

    def _e(row):
        a = _to_number(row.get(colA))
        b = lit if lit is not None else _to_number(row.get(colB_or_lit))
        if a is None or b is None:
            return None
        return {">=": a >= b - tol, "<=": a <= b + tol, ">": a > b - tol,
                "<": a < b + tol, "==": abs(a - b) <= tol}[op]
    return _e


def dateorder(earlier, later, allow_equal=True):
    def _e(row):
        a, b = _to_date(row.get(earlier)), _to_date(row.get(later))
        if a is None or b is None:
            return None
        return a <= b if allow_equal else a < b
    return _e


def identity(target, formula, tol):
    def _e(row):
        t = _to_number(row.get(target))
        f = formula(row)
        if t is None or f is None:
            return None
        return abs(t - f) <= tol
    return _e


def dom_range(col, lo, hi):
    def _e(row):
        x = _to_number(row.get(col))
        if x is None:
            return None
        if lo is not None and x < lo:
            return False
        if hi is not None and x > hi:
            return False
        return True
    return _e


def dom_set(col, allowed):
    def _e(row):
        v = row.get(col)
        return None if _is_missing(v) else (v in allowed)
    return _e


def presence(cols, must=True):
    def _e(row):
        pres = [not _is_missing(row.get(c)) for c in cols]
        return all(pres) if must else (not any(pres))
    return _e


def eq_cond(col, val):
    def _c(row):
        return not _is_missing(row.get(col)) and row.get(col) == val
    return _c


def in_cond(col, vals):
    def _c(row):
        return not _is_missing(row.get(col)) and row.get(col) in vals
    return _c


def present_number(col):
    def _e(row):
        return not _is_missing(row.get(col))
    return _e


# ============================================================================
#  SECTION 3.  GENERIC KB  (IRB + IFRS 9)  --  written in ROLES
# ============================================================================

def build_generic_kb() -> list[Rule]:
    R: list[Rule] = []

    # ---- IRB workout / LGD -------------------------------------------------
    R.append(Rule("IRB-01", "workout", "inequality",
        description="exposure_at_default >= drawn_balance (EAD cannot be below drawn balance)",
        roles=["exposure_at_default", "drawn_balance"], severity="CRITICAL",
        framework="IRB",
        build=lambda m: (_always, ineq(m["exposure_at_default"], ">=", m["drawn_balance"]))))
    R.append(Rule("IRB-02", "workout", "date_ordering",
        description="possession_date <= sale_date",
        roles=["possession_date", "sale_date"], severity="CRITICAL", framework="IRB",
        build=lambda m: (_always, dateorder(m["possession_date"], m["sale_date"]))))
    R.append(Rule("IRB-03", "workout", "conditional",
        description="IF workout closed/written_off THEN realised_lgd populated (open=censored)",
        roles=["workout_state", "realised_lgd"], severity="MATERIAL", framework="IRB",
        presence_sensitive_roles=["realised_lgd"],
        exception_notes=["'open' workouts are censored and out of scope by construction."],
        build=lambda m: (in_cond(m["workout_state"], {"closed", "written_off"}),
                         presence([m["realised_lgd"]], must=True))))
    R.append(Rule("IRB-04", "workout", "conditional",
        description="IF workout closed AND not cured THEN sale_date populated",
        roles=["workout_state", "sale_date", "cure_indicator"], severity="MATERIAL", framework="IRB",
        exceptions_spec=[("cure_indicator", 1)],
        exception_notes=["Cured workouts close without a property sale; no sale_date expected."],
        build=lambda m: (eq_cond(m["workout_state"], "closed"),
                         presence([m["sale_date"]], must=True))))
    R.append(Rule("IRB-05", "workout", "inequality",
        description="realised_loss <= exposure_at_default (cannot lose more than the exposure)",
        roles=["realised_loss", "exposure_at_default", "workout_state"],
        severity="MATERIAL", framework="IRB", presence_sensitive_roles=["realised_loss"],
        build=lambda m: (in_cond(m["workout_state"], {"closed", "written_off"}),
                         ineq(m["realised_loss"], "<=", m["exposure_at_default"]))))
    R.append(Rule("IRB-06", "workout", "identity",
        description="realised_lgd == realised_loss / exposure_at_default (+/- 0.01)",
        roles=["realised_lgd", "realised_loss", "exposure_at_default", "workout_state"],
        severity="MATERIAL", framework="IRB",
        presence_sensitive_roles=["realised_lgd", "realised_loss"],
        build=lambda m: (in_cond(m["workout_state"], {"closed", "written_off"}),
                         identity(m["realised_lgd"],
                             lambda row, mm=m: (lambda l, e: None if (l is None or e in (None, 0)) else l / e)(
                                 _to_number(row.get(mm["realised_loss"])),
                                 _to_number(row.get(mm["exposure_at_default"]))),
                             tol=0.01))))
    R.append(Rule("IRB-07", "workout", "conditional",
        description="IF cured THEN workout_state != written_off (cure/write-off exclusive)",
        roles=["cure_indicator", "workout_state"], severity="MATERIAL", framework="IRB",
        build=lambda m: (eq_cond(m["cure_indicator"], 1),
                         lambda row, mm=m: (row.get(mm["workout_state"]) != "written_off"
                                            if not _is_missing(row.get(mm["workout_state"])) else None))))
    for role, cid in [("legal_costs", "IRB-08"), ("other_costs", "IRB-09"),
                      ("sale_proceeds", "IRB-10"), ("insurance_recovery", "IRB-11"),
                      ("exposure_at_default", "IRB-12"), ("drawn_balance", "IRB-13"),
                      ("time_to_resolution", "IRB-14")]:
        R.append(Rule(cid, "workout", "domain",
            description=f"{role} >= 0 (logical bound: cannot be negative)",
            roles=[role], severity="MINOR", framework="IRB",
            build=lambda m, r=role: (_always, dom_range(m[r], 0.0, None))))
    R.append(Rule("IRB-15", "workout", "domain",
        description="workout_state in {closed, open, written_off}",
        roles=["workout_state"], severity="MATERIAL", framework="IRB",
        build=lambda m: (_always, dom_set(m["workout_state"], {"closed", "open", "written_off"}))))

    # ---- IRB origination / collateral -------------------------------------
    R.append(Rule("IRB-16", "facility", "identity",
        description="original_ltv == original_balance / original_property_value * 100 (+/- 0.5)",
        roles=["original_ltv", "original_balance", "original_property_value"],
        severity="MATERIAL", framework="IRB",
        build=lambda m: (_always, identity(m["original_ltv"],
            lambda row, mm=m: (lambda b, v: None if (b is None or v in (None, 0)) else b / v * 100.0)(
                _to_number(row.get(mm["original_balance"])),
                _to_number(row.get(mm["original_property_value"]))), tol=0.5))))
    R.append(Rule("IRB-17", "facility", "domain",
        description="original_ltv in [0, 200] (logical bound; negative LTV impossible)",
        roles=["original_ltv"], severity="MATERIAL", framework="IRB",
        build=lambda m: (_always, dom_range(m["original_ltv"], 0.0, 200.0))))
    R.append(Rule("IRB-18", "facility", "domain",
        description="term_months > 0 (positive tenor)",
        roles=["term_months"], severity="MINOR", framework="IRB",
        build=lambda m: (_always, dom_range(m["term_months"], 1.0, None))))
    for role, cid in [("original_balance", "IRB-19"),
                      ("original_property_value", "IRB-20"),
                      ("interest_rate", "IRB-21")]:
        R.append(Rule(cid, "facility", "domain",
            description=f"{role} >= 0 (logical bound)",
            roles=[role], severity="MINOR", framework="IRB",
            build=lambda m, r=role: (_always, dom_range(m[r], 0.0, None))))
    R.append(Rule("IRB-22", "facility", "domain",
        description="ftb_indicator in {0,1}",
        roles=["ftb_indicator"], severity="MINOR", framework="IRB",
        build=lambda m: (_always, dom_set(m["ftb_indicator"], {0, 1}))))

    # ---- IFRS 9 staging (snapshot spine) ----------------------------------
    R.append(Rule("IFRS9-01", "snapshot", "domain",
        description="ifrs9_stage within its declared staging domain",
        roles=["ifrs9_stage"], severity="CRITICAL", framework="IFRS9",
        exception_notes=["Domain defaults to {1,2,3}; override per dataset via mapping key "
                         "'_stage_domain' (e.g. [0,1,2,3] for a 0-based DPD bucket)."],
        build=lambda m: (_always, dom_set(m["ifrs9_stage"], set(_STAGE_DOMAIN)))))
    R.append(Rule("IFRS9-02", "snapshot", "conditional",
        description="IF days_past_due > 90 THEN ifrs9_stage = 3 (90+ DPD backstop -> Stage 3)",
        roles=["days_past_due", "ifrs9_stage"], severity="CRITICAL", framework="IFRS9",
        exception_notes=["Rebuttable 90+ DPD backstop; encode institutional rebuttals as exceptions."],
        build=lambda m: (lambda row, mm=m: (_to_number(row.get(mm["days_past_due"])) is not None
                                            and _to_number(row.get(mm["days_past_due"])) > 90),
                         lambda row, mm=m: (_to_number(row.get(mm["ifrs9_stage"])) == 3
                                            if not _is_missing(row.get(mm["ifrs9_stage"])) else None))))
    R.append(Rule("IFRS9-03", "snapshot", "conditional",
        description="IF days_past_due > 30 THEN ifrs9_stage >= 2 (30+ DPD SICR presumption)",
        roles=["days_past_due", "ifrs9_stage"], severity="MATERIAL", framework="IFRS9",
        exception_notes=["Rebuttable 30+ DPD SICR presumption; encode rebuttals as exceptions."],
        build=lambda m: (lambda row, mm=m: (_to_number(row.get(mm["days_past_due"])) is not None
                                            and _to_number(row.get(mm["days_past_due"])) > 30),
                         lambda row, mm=m: (_to_number(row.get(mm["ifrs9_stage"])) is not None
                                            and _to_number(row.get(mm["ifrs9_stage"])) >= 2)
                                            if not _is_missing(row.get(mm["ifrs9_stage"])) else None)))
    R.append(Rule("IFRS9-04", "snapshot", "conditional",
        description="IF ifrs9_stage in {2,3} THEN days_past_due present (arrears measured)",
        roles=["ifrs9_stage", "days_past_due"], severity="MINOR", framework="IFRS9",
        build=lambda m: (lambda row, mm=m: (_to_number(row.get(mm["ifrs9_stage"])) is not None
                                            and _to_number(row.get(mm["ifrs9_stage"])) >= 2),
                         lambda row, mm=m: present_number(mm["days_past_due"])(row))))
    R.append(Rule("IFRS9-05", "snapshot", "domain",
        description="days_past_due >= 0 (cannot be negative)",
        roles=["days_past_due"], severity="MATERIAL", framework="IFRS9",
        build=lambda m: (_always, dom_range(m["days_past_due"], 0.0, None))))
    R.append(Rule("IFRS9-06", "snapshot", "domain",
        description="current_balance >= 0 (logical bound)",
        roles=["current_balance"], severity="MATERIAL", framework="IRB+IFRS9",
        build=lambda m: (_always, dom_range(m["current_balance"], 0.0, None))))
    R.append(Rule("IFRS9-07", "snapshot", "identity",
        description="indexed_ltv == current_balance / indexed_property_value * 100 (+/- 0.5)",
        roles=["indexed_ltv", "current_balance", "indexed_property_value"],
        severity="MATERIAL", framework="IRB+IFRS9",
        build=lambda m: (_always, identity(m["indexed_ltv"],
            lambda row, mm=m: (lambda b, v: None if (b is None or v in (None, 0)) else b / v * 100.0)(
                _to_number(row.get(mm["current_balance"])),
                _to_number(row.get(mm["indexed_property_value"]))), tol=0.5))))
    for role, cid in [("forbearance_indicator", "IFRS9-08"),
                      ("restructure_indicator", "IFRS9-09")]:
        R.append(Rule(cid, "snapshot", "domain",
            description=f"{role} in {{0,1}}",
            roles=[role], severity="MINOR", framework="IFRS9",
            build=lambda m, r=role: (_always, dom_set(m[r], {0, 1}))))
    R.append(Rule("IFRS9-10", "snapshot", "domain",
        description="months_on_book >= 0 (logical bound)",
        roles=["months_on_book"], severity="MINOR", framework="IRB",
        build=lambda m: (_always, dom_range(m["months_on_book"], 0.0, None))))

    # ---- IRB default event -------------------------------------------------
    R.append(Rule("IRB-23", "default", "domain",
        description="materiality_indicator in {0,1}",
        roles=["materiality_indicator"], severity="MINOR", framework="IRB",
        build=lambda m: (_always, dom_set(m["materiality_indicator"], {0, 1}))))
    R.append(Rule("IRB-24", "default", "conditional",
        description="IF dod_basis = utp THEN dod_regime present (basis needs a regime stamp)",
        roles=["dod_basis", "dod_regime"], severity="MINOR", framework="IRB",
        build=lambda m: (in_cond(m["dod_basis"], {"utp", "UTP"}),
                         presence([m["dod_regime"]], must=True))))

    # ---- borrower ----------------------------------------------------------
    R.append(Rule("IRB-25", "borrower", "domain",
        description="age_at_origination in [18, 100] (logical bound)",
        roles=["age_at_origination"], severity="MATERIAL", framework="IRB",
        build=lambda m: (_always, dom_range(m["age_at_origination"], 18.0, 100.0))))
    R.append(Rule("IRB-26", "borrower", "domain",
        description="income_at_origination >= 0 (logical bound)",
        roles=["income_at_origination"], severity="MINOR", framework="IRB",
        build=lambda m: (_always, dom_range(m["income_at_origination"], 0.0, None))))

    # ---- valuation ---------------------------------------------------------
    R.append(Rule("IRB-27", "valuation", "domain",
        description="valuation_amount >= 0 (logical bound)",
        roles=["valuation_amount"], severity="MATERIAL", framework="IRB",
        build=lambda m: (_always, dom_range(m["valuation_amount"], 0.0, None))))
    R.append(Rule("IRB-28", "valuation", "domain",
        description="indexed_flag in {0,1}",
        roles=["indexed_flag"], severity="MINOR", framework="IRB",
        build=lambda m: (_always, dom_set(m["indexed_flag"], {0, 1}))))

    # ======================================================================
    #  DEEP REGULATORY EXTENSIONS  (change d)
    #  Cross-table + temporal + tighter IRB/IFRS9 integrity, each with a
    #  regulatory reference. Where a role is absent in the data, the rule ->
    #  NOT-APPLICABLE (never silently skipped).
    # ======================================================================

    # ---- TEMPORAL / CHRONOLOGY (IRB default & workout lifecycle) ----
    R.append(Rule("IRB-30", "workout", "date_ordering",
        description="default_date <= possession_date (default precedes repossession)",
        roles=["default_date", "possession_date"], severity="CRITICAL", framework="IRB",
        reg_reference="CRR Art. 178; EBA/GL/2016/07",
        build=lambda m: (_always, dateorder(m["default_date"], m["possession_date"]))))
    R.append(Rule("IRB-31", "workout", "date_ordering",
        description="default_date <= sale_date (default precedes collateral sale)",
        roles=["default_date", "sale_date"], severity="CRITICAL", framework="IRB",
        reg_reference="EBA/GL/2017/16 (LGD, recovery timing)",
        build=lambda m: (_always, dateorder(m["default_date"], m["sale_date"]))))
    R.append(Rule("IRB-32", "workout", "conditional",
        description="IF workout closed THEN time_to_resolution present",
        roles=["workout_state", "time_to_resolution"], severity="MATERIAL", framework="IRB",
        reg_reference="EBA/GL/2017/16 para 158 (realised LGD)",
        presence_sensitive_roles=["time_to_resolution"],
        build=lambda m: (eq_cond(m["workout_state"], "closed"),
                         presence([m["time_to_resolution"]], must=True))))

    # ---- CROSS-TABLE consistency (facility <-> workout) ----
    R.append(Rule("IRB-33", "workout", "inequality",
        description="exposure_at_default <= original_balance * 1.5 (EAD bounded vs original)",
        roles=["exposure_at_default", "original_balance"], severity="MATERIAL", framework="IRB",
        reg_reference="CRR Art. 166 (exposure value)",
        exception_notes=["Factor 1.5 allows fees/arrears capitalisation; tune per portfolio."],
        build=lambda m: (_always,
                         lambda row, mm=m: (lambda e, b: None if (e is None or b in (None, 0)) else e <= b * 1.5)(
                             _to_number(row.get(mm["exposure_at_default"])),
                             _to_number(row.get(mm["original_balance"]))))))
    R.append(Rule("IRB-34", "workout", "inequality",
        description="drawn_balance <= original_balance * 1.5 (balance-at-default vs original)",
        roles=["drawn_balance", "original_balance"], severity="MATERIAL", framework="IRB",
        reg_reference="CRR Art. 166; amortisation sanity",
        build=lambda m: (_always,
                         lambda row, mm=m: (lambda d, b: None if (d is None or b in (None, 0)) else d <= b * 1.5)(
                             _to_number(row.get(mm["drawn_balance"])),
                             _to_number(row.get(mm["original_balance"]))))))

    # ---- IRB LGD component integrity ----
    R.append(Rule("IRB-35", "workout", "domain",
        description="realised_lgd in [-0.10, 1.50] (downturn LGD plausibility bound)",
        roles=["realised_lgd"], severity="MATERIAL", framework="IRB",
        reg_reference="EBA/GL/2017/16 (LGD)",
        exception_notes=["Wide LOGICAL bound, not typical [0,1]; typical-range checks route to distributional test."],
        build=lambda m: (_always, dom_range(m["realised_lgd"], -0.10, 1.50))))
    R.append(Rule("IRB-36", "workout", "conditional",
        description="IF cured THEN realised_lgd <= 0.05 (a genuine cure implies ~no loss)",
        roles=["cure_indicator", "realised_lgd"], severity="MATERIAL", framework="IRB",
        reg_reference="EBA/GL/2017/16 (cure definition)",
        presence_sensitive_roles=["realised_lgd"],
        build=lambda m: (eq_cond(m["cure_indicator"], 1),
                         lambda row, mm=m: (lambda l: None if l is None else l <= 0.05)(
                             _to_number(row.get(mm["realised_lgd"]))))))

    # ---- IFRS 9 staging integrity (deeper) ----
    R.append(Rule("IFRS9-20", "snapshot", "conditional",
        description="IF forbearance THEN ifrs9_stage >= 2 (forbearance is a SICR trigger)",
        roles=["forbearance_indicator", "ifrs9_stage"], severity="MATERIAL", framework="IFRS9",
        reg_reference="IFRS 9 B5.5.17; EBA/GL/2018/06",
        exception_notes=["Rebuttable where forbearance did not increase credit risk; encode as exception."],
        build=lambda m: (eq_cond(m["forbearance_indicator"], 1),
                         lambda row, mm=m: (lambda s: None if s is None else s >= 2)(
                             _to_number(row.get(mm["ifrs9_stage"]))))))
    R.append(Rule("IFRS9-21", "snapshot", "conditional",
        description="IF ifrs9_stage = 1 THEN days_past_due <= 30 (Stage 1 excludes 30+ DPD)",
        roles=["ifrs9_stage", "days_past_due"], severity="MATERIAL", framework="IFRS9",
        reg_reference="IFRS 9 5.5.11 (30 DPD presumption)",
        build=lambda m: (eq_cond_num(m["ifrs9_stage"], 1),
                         lambda row, mm=m: (lambda d: None if d is None else d <= 30)(
                             _to_number(row.get(mm["days_past_due"]))))))
    R.append(Rule("IFRS9-22", "snapshot", "conditional",
        description="IF ifrs9_stage = 3 THEN days_past_due present (credit-impaired measured)",
        roles=["ifrs9_stage", "days_past_due"], severity="MINOR", framework="IFRS9",
        reg_reference="IFRS 9 Appendix A (credit-impaired)",
        build=lambda m: (eq_cond_num(m["ifrs9_stage"], 3),
                         lambda row, mm=m: present_number(mm["days_past_due"])(row))))
    R.append(Rule("IFRS9-23", "snapshot", "conditional",
        description="IF forbearance THEN restructure flag or arrears (not a clean Stage 1)",
        roles=["forbearance_indicator", "restructure_indicator", "days_past_due"],
        severity="MINOR", framework="IFRS9",
        reg_reference="EBA/GL/2018/06 (forbearance classification)",
        exception_notes=["Soft cross-check; forborne with 0 DPD and no restructure flag is unusual."],
        build=lambda m: (eq_cond(m["forbearance_indicator"], 1),
                         lambda row, mm=m: (
                             (row.get(mm["restructure_indicator"]) == 1) or
                             ((_to_number(row.get(mm["days_past_due"])) or 0) > 0)))))

    return R


def eq_cond_num(col, val):
    """Condition: numeric value of col equals val (handles 1 vs 1.0)."""
    def _c(row):
        x = _to_number(row.get(col))
        return x is not None and x == val
    return _c


# ============================================================================
#  SECTION 4.  ROLE RESOLUTION  (auto-match + manual override)
# ============================================================================

@dataclass
class RoleMatch:
    role: str
    table: Optional[str]
    column: Optional[str]
    score: float
    reason: str
    via: str          # "override" | "auto" | "unresolved"


def _dict_desc(dictionary: Optional[dict], table: str, col: str) -> str:
    if not dictionary:
        return ""
    t = dictionary.get("tables", {}).get(table, {})
    c = t.get("columns", {}).get(col, {})
    return (c.get("description") or c.get("notes") or "").lower()


def _canon(s: str) -> str:
    """canonical form: lowercase, non-alphanumerics -> single space, stripped."""
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def _tokens(s: str) -> set:
    return set(_canon(s).split())


def _score_column(role, meta, table, col, desc, series):
    """Return (score in [0,1], reason). Confidence genuinely varies by evidence
    quality so the number is informative rather than a disguised string-equality:
      1.00  exact canonical name == role name
      0.92  exact canonical name == a synonym
      0.88  dictionary description phrase-matches a synonym
      0.80  full token-set of a synonym is a subset of the column's tokens
      0.55-0.75  fuzzy character similarity (graded by ratio)
      0.35-0.60  partial token overlap (Jaccard), graded
    A dtype gate can veto (returns 0.0). Scores are NOT snapped to round numbers."""
    col_c = _canon(col)
    col_tok = _tokens(col)
    syns = meta["synonyms"]
    role_name = role  # role id, e.g. 'exposure_at_default'

    best, why = 0.0, "no match"

    def consider(score, reason):
        nonlocal best, why
        if score > best:
            best, why = score, reason

    # 1.00 exact name == role
    if col_c == _canon(role_name):
        consider(1.00, "column name is the role name (exact)")
    # 0.92 exact name == synonym
    for s in syns:
        if col_c == _canon(s):
            consider(0.92, f"column name exactly matches synonym '{s}'")
    # 0.88 dictionary description contains a synonym phrase
    if desc:
        for s in syns:
            if _canon(s) and _canon(s) in _canon(desc):
                consider(0.88, f"dictionary description mentions '{s}'")
    # 0.80 synonym token-set fully contained in column tokens
    for s in syns:
        st = _tokens(s)
        if st and st.issubset(col_tok):
            consider(0.80, f"column tokens contain all of synonym '{s}'")
    # fuzzy character similarity, graded 0.55..0.75
    for s in syns:
        ratio = difflib.SequenceMatcher(None, col_c, _canon(s)).ratio()
        if ratio >= 0.80:
            consider(0.55 + 0.20 * (ratio - 0.80) / 0.20,
                     f"name similar to '{s}' ({ratio:.2f})")
    # partial token overlap (Jaccard), graded 0.35..0.60
    for s in syns:
        st = _tokens(s)
        if st and col_tok:
            jac = len(st & col_tok) / len(st | col_tok)
            if jac > 0:
                consider(0.35 + 0.25 * jac, f"partial token overlap with '{s}' ({jac:.2f})")

    # dtype plausibility gate (can veto)
    if best > 0:
        dt = meta["dtype"]
        non_null = series.dropna()
        if len(non_null) > 0:
            if dt in ("number", "flag"):
                coerce = sum(1 for v in non_null.head(200) if _to_number(v) is not None)
                if coerce < 0.6 * min(200, len(non_null)):
                    return 0.0, "dtype mismatch (not numeric)"
            if dt == "flag":
                vals = set(str(x) for x in non_null.unique().tolist()[:12])
                if not vals.issubset({"0", "1", "0.0", "1.0", "True", "False"}):
                    return 0.0, "dtype mismatch (not binary)"
    return round(best, 3), why


def resolve_roles(kb, tables, dictionary, override, extra_roles=()):
    needed = sorted({r for rule in kb for r in rule.roles} | set(extra_roles))
    resolved = {}
    for role in needed:
        if role not in ROLE_VOCAB:
            resolved[role] = RoleMatch(role, None, None, 0.0, "role not in vocabulary", "unresolved")
            continue
        meta = ROLE_VOCAB[role]
        if role in override:
            spec = override[role]
            if "." in spec:
                tbl, col = spec.split(".", 1)
            else:
                tbl, col = None, spec
                for tname, df in tables.items():
                    if col in df.columns:
                        tbl = tname
                        break
            resolved[role] = RoleMatch(role, tbl, col, 1.0, "manual override", "override")
            continue
        best = RoleMatch(role, None, None, 0.0, "no candidate", "unresolved")
        for tname, df in tables.items():
            for col in df.columns:
                desc = _dict_desc(dictionary, tname, col)
                sc, why = _score_column(role, meta, tname, col, desc, df[col])
                if sc > best.score:
                    best = RoleMatch(role, tname, col, sc, why, "auto")
        if best.score < 0.70:
            best = RoleMatch(role, None, None, best.score,
                             f"best candidate too weak (score {best.score:.2f})", "unresolved")
        resolved[role] = best
    return resolved


def print_resolution(resolved):
    step("STEP 3  ROLE RESOLUTION  (generic role -> real column)")
    n_ok = sum(1 for m in resolved.values() if m.column)
    note(f"{n_ok}/{len(resolved)} roles resolved.")
    print(f"    {'ROLE':<26}{'-> COLUMN':<34}{'VIA':<10}SCORE  WHY")
    for role in sorted(resolved):
        m = resolved[role]
        tgt = f"{m.table}.{m.column}" if m.column else "(unresolved)"
        print(f"    {role:<26}{tgt:<34}{m.via:<10}{m.score:>4.2f}  {m.reason}")


# ============================================================================
#  SECTION 5.  DATA LOADING & FOLDER DISCOVERY
# ============================================================================

def load_data(path):
    ext = os.path.splitext(path)[1].lower()
    tables = {}
    if ext in (".xlsx", ".xlsm", ".xls"):
        xl = pd.ExcelFile(path)
        for sheet in xl.sheet_names:
            tables[sheet] = xl.parse(sheet)
    elif ext in (".csv", ".tsv"):
        sep = "\t" if ext == ".tsv" else ","
        tables[os.path.splitext(os.path.basename(path))[0]] = pd.read_csv(path, sep=sep)
    else:
        raise ValueError(f"unsupported data format: {ext}")
    return tables


def discover_folder(folder):
    found = {"data": None, "dictionary": None, "mapping": None}
    cands = []
    for ext in ("*.xlsx", "*.xlsm", "*.xls", "*.csv", "*.tsv"):
        cands += glob.glob(os.path.join(folder, ext))
    if cands:
        found["data"] = sorted(cands)[0]
    for name, key in [("dictionary.json", "dictionary"), ("mapping.json", "mapping")]:
        p = os.path.join(folder, name)
        if os.path.exists(p):
            found[key] = p
    return found


# ============================================================================
#  SECTION 6.  ENTITY -> TABLE BINDING
# ============================================================================

def bind_entities(resolved):
    from collections import Counter, defaultdict
    votes = defaultdict(Counter)
    for role, m in resolved.items():
        if not m.column:
            continue
        ent = ROLE_VOCAB.get(role, {}).get("entity", "*")
        if ent == "*":
            continue
        votes[ent][m.table] += 1
    binding = {ent: ct.most_common(1)[0][0] for ent, ct in votes.items()}
    if _VERBOSE:
        step("STEP 4  ENTITY -> TABLE BINDING")
        for ent, tbl in sorted(binding.items()):
            note(f"{ent:<12} -> {tbl}")
    return binding


# ============================================================================
#  SECTION 7.  EVALUATION
# ============================================================================

@dataclass
class RuleResult:
    rule: Rule
    outcome: str
    scope_n: int = 0
    excepted_n: int = 0
    skipped_semantics_n: int = 0
    violation_n: int = 0
    violation_rate: float = 0.0
    examples: list = field(default_factory=list)
    pattern: Optional[str] = None
    pattern_detail: str = ""
    na_reason: str = ""
    resolved_map: dict = field(default_factory=dict)


def evaluate_rule(rule, resolved, binding, tables, grain_role, segment_role,
                  cluster_lift, cluster_coverage):
    role_to_col = {}
    for role in rule.roles:
        m = resolved.get(role)
        if not m or not m.column:
            return RuleResult(rule=rule, outcome="NOT-APPLICABLE",
                              na_reason=f"role '{role}' unmapped")
        role_to_col[role] = m.column

    # locate each role's (table, column); a rule may span multiple tables
    role_tables = {role: resolved[role].table for role in rule.roles}
    needed_tables = set(role_tables.values())

    if len(needed_tables) == 1:
        table = next(iter(needed_tables))
        df = tables[table]
    else:
        # CROSS-TABLE rule: join participating tables on the grain key
        gm = resolved.get(grain_role)
        if not gm or not gm.column:
            return RuleResult(rule=rule, outcome="NOT-APPLICABLE",
                              na_reason="cross-table rule but grain key unresolved; cannot join")
        key = gm.column
        base_t = role_tables[rule.roles[0]]
        if key not in tables[base_t].columns:
            return RuleResult(rule=rule, outcome="NOT-APPLICABLE",
                              na_reason=f"grain key '{key}' absent in base table '{base_t}'")
        df = tables[base_t].copy()
        joined = [base_t]
        for role in rule.roles:
            rt = role_tables[role]
            col = role_to_col[role]
            if rt == base_t or col in df.columns:
                continue
            right_df = tables.get(rt)
            if right_df is None or key not in right_df.columns or col not in right_df.columns:
                return RuleResult(rule=rule, outcome="NOT-APPLICABLE",
                                  na_reason=f"role '{role}' in '{rt}' not joinable on '{key}'")
            right = right_df[[key, col]].dropna(subset=[key]).groupby(key, as_index=False).first()
            df = df.merge(right, on=key, how="left")
            if rt not in joined:
                joined.append(rt)
        table = "+".join(joined)
    missing = [c for c in role_to_col.values() if c not in df.columns]
    if missing:
        return RuleResult(rule=rule, outcome="NOT-APPLICABLE",
                          na_reason=f"column(s) absent in {table}: {', '.join(missing)}")

    condition, expression = rule.build(role_to_col)
    exc_fns = [eq_cond(role_to_col[r], v) for (r, v) in rule.exceptions_spec if r in role_to_col]

    grain_col = resolved.get(grain_role).column if resolved.get(grain_role) else None
    seg_col = resolved.get(segment_role).column if resolved.get(segment_role) else None

    records = df.to_dict("records")
    scope = [row for row in records if condition(row)]
    if not scope:
        return RuleResult(rule=rule, outcome="NOT-APPLICABLE",
                          na_reason="empty scope (no rows meet IF-condition)",
                          resolved_map=role_to_col)

    violations, excepted, evaluated, skipped = [], 0, 0, 0
    for row in scope:
        v = expression(row)
        if v is None:
            skipped += 1
            continue
        evaluated += 1
        if v is True:
            continue
        if any(fn(row) for fn in exc_fns):
            excepted += 1
            continue
        violations.append(row)

    if evaluated == 0:
        return RuleResult(rule=rule, outcome="NOT-APPLICABLE", scope_n=len(scope),
                          skipped_semantics_n=skipped, resolved_map=role_to_col,
                          na_reason="all in-scope rows had missing/censored values")

    rate = len(violations) / evaluated
    outcome = "PASS" if rate <= rule.tolerance else "VIOLATION"
    examples = []
    for row in violations[:5]:
        ex = {}
        if grain_col and grain_col in row:
            ex[grain_col] = row[grain_col]
        for c in role_to_col.values():
            ex[c] = row.get(c)
        examples.append(ex)

    res = RuleResult(rule=rule, outcome=outcome, scope_n=evaluated, excepted_n=excepted,
                     skipped_semantics_n=skipped, violation_n=len(violations),
                     violation_rate=rate, examples=examples, resolved_map=role_to_col)
    if outcome == "VIOLATION" and seg_col:
        res.pattern, res.pattern_detail = violation_pattern(
            scope, violations, seg_col, cluster_lift, cluster_coverage)
    return res


def violation_pattern(scope, violations, seg_col, cluster_lift, cluster_coverage):
    from collections import Counter
    st, vt = len(scope), len(violations)
    if st == 0 or vt == 0 or not seg_col:
        return None, "no axis"
    sc = Counter(r.get(seg_col) for r in scope)
    vc = Counter(r.get(seg_col) for r in violations)
    lifts = {lvl: (v / vt) / (sc.get(lvl, 0) / st) if sc.get(lvl, 0) else float("inf")
             for lvl, v in vc.items()}
    if not lifts:
        return None, "no axis"
    top = max(lifts, key=lifts.get)
    high = [l for l, lf in lifts.items() if lf >= cluster_lift]
    cover = sum(vc[l] for l in high) / vt
    if lifts[top] >= cluster_lift and cover >= cluster_coverage:
        return "CLUSTERED", (f"CLUSTERED on '{seg_col}': top {top!r} lift={lifts[top]:.1f}; "
                             f"high-lift levels cover {cover:.0%} (lift>={cluster_lift}, "
                             f"coverage>={cluster_coverage}). Suggests a feed/segment fault.")
    return "SCATTERED", (f"SCATTERED on '{seg_col}': top {top!r} lift={lifts[top]:.1f}, "
                         f"coverage {cover:.0%} (lift>={cluster_lift}, coverage>={cluster_coverage}). "
                         f"Suggests capture error.")


# ============================================================================
#  SECTION 8.  REPORT
# ============================================================================

def _sev_rank(s):
    return {"CRITICAL": 0, "MATERIAL": 1, "MINOR": 2}.get(s, 3)


def build_report(results, preamble):
    L = []
    W = L.append
    W("=" * 78)
    W("CROSS-FIELD BUSINESS RULE TEST  --  REPORT  (generic KB: IRB + IFRS 9)")
    W("=" * 78)
    W("\nPREAMBLE\n" + "-" * 78)
    W(f"  Rule-set source   : {preamble['source']}")
    W(f"  Framework scope   : IRB + IFRS 9")
    W(f"  Dataset           : {preamble['dataset']}")
    W(f"  Rules loaded      : {preamble['n_rules']}")
    W(f"  Rules by type     : " + ", ".join(f"{k}={v}" for k, v in sorted(preamble['by_type'].items())))
    W(f"  Roles resolved    : {preamble['roles_resolved']}/{preamble['roles_total']} "
      f"({preamble['roles_override']} override, {preamble['roles_auto']} auto)")
    W(f"  Pattern knobs     : cluster_lift={preamble['cluster_lift']}, "
      f"cluster_coverage={preamble['cluster_coverage']}")
    W("")
    passed = [r for r in results if r.outcome == "PASS"]
    viol = [r for r in results if r.outcome == "VIOLATION"]
    na = [r for r in results if r.outcome == "NOT-APPLICABLE"]
    W("DATASET ROLL-UP\n" + "-" * 78)
    W(f"  PASS           : {len(passed)}")
    W(f"  VIOLATION      : {len(viol)}")
    W(f"  NOT-APPLICABLE : {len(na)}\n")
    viol.sort(key=lambda r: (_sev_rank(r.rule.severity), -r.violation_rate))
    if viol:
        W("VIOLATIONS  (verdicts, ordered by severity)\n" + "=" * 78)
        for r in viol:
            W(f"[{r.rule.severity}] {r.rule.id}  ({r.rule.framework} / {r.rule.rule_type})")
            W(f"   Rule      : {r.rule.description}")
            if r.rule.reg_reference:
                W(f"   Reg ref   : {r.rule.reg_reference}")
            W(f"   Resolved  : " + ", ".join(f"{k}->{v}" for k, v in r.resolved_map.items()))
            W(f"   Scope     : {r.scope_n} rows evaluated"
              + (f", {r.skipped_semantics_n} skipped (missing/censored)" if r.skipped_semantics_n else ""))
            W(f"   Violations: {r.violation_n}  (rate {r.violation_rate:.4%}, tol {r.rule.tolerance})")
            if r.excepted_n:
                W(f"   Exceptions applied: {r.excepted_n}")
                for n in r.rule.exception_notes:
                    W(f"       - {n}")
            if r.pattern:
                W(f"   Pattern   : {r.pattern_detail}")
            W("   Evidence  (up to 5 rows):")
            for ex in r.examples:
                W("       - " + ", ".join(f"{k}={v}" for k, v in ex.items()))
            W("")
    else:
        W("VIOLATIONS\n" + "-" * 78 + "\n  None.\n")
    if passed:
        W("PASSES\n" + "-" * 78)
        for r in sorted(passed, key=lambda x: x.rule.id):
            W(f"  [{r.rule.severity}] {r.rule.id}  scope={r.scope_n}  viol={r.violation_n}  "
              f"({r.rule.description})")
        W("")
    if na:
        W("NOT-APPLICABLE  (stated, never hidden)\n" + "-" * 78)
        for r in sorted(na, key=lambda x: x.rule.id):
            W(f"  {r.rule.id}  ({r.rule.framework})  -> {r.na_reason}")
        W("")
    W("=" * 78)
    W("End of report.  Evidence rows available in full on request.")
    W("=" * 78)
    return "\n".join(L)


# ============================================================================
#  SECTION 9.  CLI
# ============================================================================

# ============================================================================
#  SECTION 8b.  USE-CASE SELECTION  (change b)
# ============================================================================

def choose_use_case(cli_value: Optional[str]) -> set:
    """Return the set of frameworks to run: {'IRB'}, {'IFRS9'}, or both.
    A rule's framework 'IRB+IFRS9' runs if EITHER is selected. Interactive by
    default; --usecase can pre-answer for non-interactive runs."""
    mapping = {"irb": {"IRB"}, "ifrs9": {"IFRS9"}, "ifrs": {"IFRS9"},
               "both": {"IRB", "IFRS9"}, "all": {"IRB", "IFRS9"}}
    if cli_value:
        key = cli_value.strip().lower()
        if key in mapping:
            return mapping[key]
    step("STEP 1b  SELECT USE CASE")
    print("    Which regulatory use case should this run test?")
    print("      [1] IRB      (PD / LGD / EAD model data integrity)")
    print("      [2] IFRS 9   (staging / SICR / ECL component integrity)")
    print("      [3] Both")
    try:
        ans = input("    Enter 1, 2, or 3: ").strip()
    except (EOFError, KeyboardInterrupt):
        ans = "3"
        print("\n    (no input available -> defaulting to Both)")
    chosen = {"1": {"IRB"}, "2": {"IFRS9"}, "3": {"IRB", "IFRS9"}}.get(ans, {"IRB", "IFRS9"})
    note(f"use case selected: {', '.join(sorted(chosen))}")
    return chosen


def filter_kb_by_framework(kb: list, chosen: set) -> list:
    """Keep a rule if any of its framework tokens is in the chosen set.
    'IRB+IFRS9' rules run whenever either framework is chosen."""
    kept = []
    for r in kb:
        toks = set(r.framework.replace("+", " ").split())
        if toks & chosen:
            kept.append(r)
    return kept


# ============================================================================
#  SECTION 8c.  LLM COLUMN-VERIFICATION LAYER  (change c)  --  PLACEHOLDER API
# ============================================================================
# After deterministic auto-match, an LLM is asked to sanity-check each
# role -> column choice against the column's name, dictionary description, and a
# small data sample. Where the LLM DISAGREES, the engine pauses and asks the
# user to choose (per conflict). The rule engine itself remains fully
# deterministic; the LLM only touches the MAPPING, never a verdict.
#
# The API call is a PLACEHOLDER. Wire a real provider inside `_llm_call`.

def _llm_call(prompt: str) -> Optional[dict]:
    """PLACEHOLDER for a real LLM call. Return a dict like
    {"agree": bool, "suggestion": "table.column" or None, "reason": str}
    or None when the layer is disabled / no API configured.

    To enable: set the env var CFR_LLM_API_KEY and implement the request below
    (e.g. Anthropic Messages API). Left unimplemented on purpose so the engine
    runs offline and deterministically by default."""
    import os
    api_key = os.environ.get("CFR_LLM_API_KEY")
    if not api_key:
        return None
    # ------------------------------------------------------------------
    # REAL IMPLEMENTATION GOES HERE, e.g.:
    #   import anthropic
    #   client = anthropic.Anthropic(api_key=api_key)
    #   resp = client.messages.create(model=..., max_tokens=300,
    #            messages=[{"role":"user","content":prompt}])
    #   return json.loads(resp.content[0].text)
    # ------------------------------------------------------------------
    raise NotImplementedError(
        "CFR_LLM_API_KEY is set but _llm_call is a placeholder. "
        "Implement the provider request to enable LLM verification.")


def _sample_values(series, k: int = 8) -> list:
    vals = series.dropna().unique().tolist()[:k]
    return [str(v) for v in vals]


def verify_mapping_with_llm(resolved: dict, tables: dict, dictionary: Optional[dict],
                            enabled: bool) -> dict:
    """For each resolved role, ask the LLM whether the chosen column is correct.
    On disagreement, PAUSE and ask the user to pick (per conflict). Returns the
    (possibly amended) resolved map. Fully skipped when disabled or no API."""
    if not enabled:
        return resolved
    step("STEP 3b  LLM COLUMN VERIFICATION  (placeholder API)")
    # probe whether the API is actually wired
    probe = None
    try:
        probe = _llm_call("ping")
    except NotImplementedError as e:
        note(f"LLM layer requested but not implemented: {e}")
        note("skipping verification; run stays deterministic.")
        return resolved
    if probe is None:
        note("No LLM API configured (CFR_LLM_API_KEY unset) -> skipping verification.")
        return resolved

    amended = dict(resolved)
    for role, m in resolved.items():
        if not m or not m.column:
            continue
        df = tables.get(m.table)
        if df is None or m.column not in df.columns:
            continue
        desc = _dict_desc(dictionary, m.table, m.column)
        prompt = _build_llm_prompt(role, m, desc, _sample_values(df[m.column]))
        try:
            verdict = _llm_call(prompt)
        except NotImplementedError:
            continue
        if not verdict or verdict.get("agree", True):
            continue
        # DISAGREEMENT -> pause and ask the user (per conflict)
        amended[role] = _resolve_conflict_with_user(role, m, verdict, tables)
    return amended


def _build_llm_prompt(role, m, desc, samples) -> str:
    return (
        "You verify data-column mappings for a regulatory data-quality engine.\n"
        f"Semantic role: {role}\n"
        f"Auto-matched column: {m.table}.{m.column} (confidence {m.score:.2f})\n"
        f"Column dictionary description: {desc or '(none)'}\n"
        f"Sample values: {samples}\n"
        "Does this column correctly represent the role? Respond as JSON: "
        '{"agree": true/false, "suggestion": "table.column" or null, "reason": "..."}')


def _resolve_conflict_with_user(role, m, verdict, tables) -> "RoleMatch":
    print("\n    " + "!" * 60)
    print(f"    LLM DISAGREES on role '{role}'")
    print(f"      auto-match : {m.table}.{m.column}  (score {m.score:.2f})")
    print(f"      LLM says   : {verdict.get('suggestion') or '(no column is right)'}")
    print(f"      reason     : {verdict.get('reason', '')}")
    print("    " + "!" * 60)
    print("    Choose:  [1] keep auto-match   [2] use LLM suggestion   [3] enter column")
    try:
        ans = input("    Enter 1, 2, or 3: ").strip()
    except (EOFError, KeyboardInterrupt):
        ans = "1"
        print("\n    (no input -> keeping auto-match)")
    if ans == "2" and verdict.get("suggestion") and "." in verdict["suggestion"]:
        tbl, col = verdict["suggestion"].split(".", 1)
        return RoleMatch(role, tbl, col, 1.0, "user accepted LLM suggestion", "llm+user")
    if ans == "3":
        try:
            spec = input("    Enter table.column: ").strip()
        except (EOFError, KeyboardInterrupt):
            spec = ""
        if "." in spec:
            tbl, col = spec.split(".", 1)
            return RoleMatch(role, tbl, col, 1.0, "user manual override (post-LLM)", "user")
    return m  # keep auto-match


def main(argv=None):
    global _VERBOSE
    ap = argparse.ArgumentParser(description="Cross-field business rule engine (generic KB, IRB+IFRS9, no AI).")
    ap.add_argument("--folder", help="Run folder: auto-find data + dictionary.json + mapping.json.")
    ap.add_argument("--data", help="Explicit data path (.xlsx/.csv).")
    ap.add_argument("--dictionary", help="Explicit data dictionary JSON.")
    ap.add_argument("--mapping", help="Explicit role->column override JSON.")
    ap.add_argument("--report", help="Report output path.")
    ap.add_argument("--grain-role", default="facility_id")
    ap.add_argument("--segment-role", default="region")
    ap.add_argument("--cluster-lift", type=float, default=3.0)
    ap.add_argument("--cluster-coverage", type=float, default=0.50)
    ap.add_argument("--dump-roles", help="Write the role vocabulary to JSON and exit.")
    ap.add_argument("--usecase", help="Pre-answer use case: irb | ifrs9 | both (else asked interactively).")
    ap.add_argument("--verify-llm", action="store_true",
                    help="Enable the LLM column-verification layer (needs CFR_LLM_API_KEY + wired _llm_call).")
    ap.add_argument("--quiet", action="store_true", help="Suppress intermediary step output.")
    args = ap.parse_args(argv)

    if args.quiet:
        _VERBOSE = False

    if args.dump_roles:
        with open(args.dump_roles, "w", encoding="utf-8") as fh:
            json.dump(ROLE_VOCAB, fh, indent=2)
        print(f"Wrote role vocabulary to {args.dump_roles}")
        return 0

    data_path, dict_path, map_path, out_folder = args.data, args.dictionary, args.mapping, None
    folder = args.folder or (os.getcwd() if not args.data else None)
    if folder:
        out_folder = folder
        disc = discover_folder(folder)
        data_path = data_path or disc["data"]
        dict_path = dict_path or disc["dictionary"]
        map_path = map_path or disc["mapping"]
        step("STEP 0  FOLDER DISCOVERY")
        note(f"folder      : {folder}")
        note(f"data        : {data_path}")
        note(f"dictionary  : {dict_path or '(none)'}")
        note(f"mapping     : {map_path or '(none)'}")
    if not data_path:
        ap.error("no data file (use --data or put one in --folder)")

    step("STEP 1  LOAD DATA")
    tables = load_data(data_path)
    for t, df in tables.items():
        note(f"table '{t}': {len(df):,} rows x {len(df.columns)} cols")

    dictionary = None
    if dict_path:
        with open(dict_path, "r", encoding="utf-8") as fh:
            dictionary = json.load(fh)
    override = {}
    if map_path:
        with open(map_path, "r", encoding="utf-8") as fh:
            override = json.load(fh)
    # pull configuration keys (prefixed with '_') out of the role-override map
    global _STAGE_DOMAIN
    if "_stage_domain" in override:
        _STAGE_DOMAIN = override.pop("_stage_domain")
        note(f"IFRS 9 stage domain overridden to {_STAGE_DOMAIN}")

    # ---- change (b): choose use case, then filter the KB ----
    chosen = choose_use_case(getattr(args, "usecase", None))

    step("STEP 2  LOAD GENERIC KB")
    kb_all = build_generic_kb()
    kb = filter_kb_by_framework(kb_all, chosen)
    from collections import Counter
    note(f"use case {', '.join(sorted(chosen))}: {len(kb)} of {len(kb_all)} rules apply")
    note("rules by framework: "
         + ", ".join(f"{k}={v}" for k, v in sorted(Counter(r.framework for r in kb).items())))

    resolved = resolve_roles(kb, tables, dictionary, override,
                             extra_roles=[args.grain_role])
    if _VERBOSE:
        print_resolution(resolved)

    # ---- change (c): optional LLM verification of column choices ----
    resolved = verify_mapping_with_llm(resolved, tables, dictionary,
                                       enabled=getattr(args, "verify_llm", False))

    binding = bind_entities(resolved)

    step("STEP 5  EVALUATE RULES")
    results = []
    for rule in kb:
        res = evaluate_rule(rule, resolved, binding, tables,
                            args.grain_role, args.segment_role,
                            args.cluster_lift, args.cluster_coverage)
        results.append(res)
        if _VERBOSE:
            extra = ""
            if res.outcome == "VIOLATION":
                extra = f"  {res.violation_n}/{res.scope_n} ({res.violation_rate:.2%})"
            elif res.outcome == "PASS":
                extra = f"  0/{res.scope_n}"
            elif res.outcome == "NOT-APPLICABLE":
                extra = f"  ({res.na_reason})"
            note(f"{rule.id:<10}[{rule.severity:<8}] {res.outcome:<15}{extra}")

    step("STEP 6  REPORT")
    roles_total = len(resolved)
    preamble = {
        "source": "generic role-based KB",
        "dataset": os.path.basename(data_path),
        "n_rules": len(kb),
        "by_type": dict(Counter(r.rule_type for r in kb)),
        "roles_total": roles_total,
        "roles_resolved": sum(1 for m in resolved.values() if m.column),
        "roles_override": sum(1 for m in resolved.values() if m.via == "override"),
        "roles_auto": sum(1 for m in resolved.values() if m.via == "auto"),
        "cluster_lift": args.cluster_lift,
        "cluster_coverage": args.cluster_coverage,
    }
    report = build_report(results, preamble)
    print("\n" + report)

    report_path = args.report or (os.path.join(out_folder, "report.txt") if out_folder else None)
    if report_path:
        with open(report_path, "w", encoding="utf-8") as fh:
            fh.write(report)
        print(f"\n[report written to {report_path}]")
    if out_folder:
        rm = {role: (f"{m.table}.{m.column}" if m.column else None)
              for role, m in resolved.items()}
        rmp = os.path.join(out_folder, "resolution_map.json")
        with open(rmp, "w", encoding="utf-8") as fh:
            json.dump(rm, fh, indent=2)
        print(f"[resolution map written to {rmp}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
